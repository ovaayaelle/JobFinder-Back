const { DataTypes } = require('sequelize');
const sequelize = require('../config');

const Stage = sequelize.define('Stage', {
    id: {
        type: DataTypes.INTEGER,
        autoIncrement: true,
        primaryKey: true
    },
    title: {
        type: DataTypes.STRING,
        allowNull: false
    },
    description: {
        type: DataTypes.TEXT,
        allowNull: false
    },
    company: {
        type: DataTypes.STRING,
        allowNull: false
    },
    email: {
      type: DataTypes.STRING,
      allowNull: false, // ou true, selon vos besoins
    },
    location: {
        type: DataTypes.STRING,
        allowNull: false
    },
    posted_date: {
        type: DataTypes.DATE,
        allowNull: false
    }
}, {
    tableName: 'stage_search_db',
    timestamps: false
});

module.exports = Stage;
