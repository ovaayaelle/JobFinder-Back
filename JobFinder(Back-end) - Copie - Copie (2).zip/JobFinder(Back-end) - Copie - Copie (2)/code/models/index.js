const sequelize = require('../config');
const Job = require('./job');
const Stage = require('./stage');

const db = {
    sequelize,
    Job,
    Stage
};

module.exports = db;
