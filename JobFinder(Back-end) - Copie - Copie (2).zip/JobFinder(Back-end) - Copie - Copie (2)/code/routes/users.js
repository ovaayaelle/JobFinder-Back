const express = require('express');
const bcrypt = require('bcrypt');
const router = express.Router();
const path = require('path');
const upload = require('../upload');
const User = require('../models/user');
const authenticateToken = require('../middleware/auth');

router.get('/', async (req, res) => {
    try {
        const users = await User.findAll();
        res.json(users);
    } catch (err) {
        res.status(500).json({ message: err.message });
    }
});

router.get('/:id', async (req, res) => {
    try {
        const user = await User.findByPk(req.params.id);
        if (user) {
            res.json(user);
        } else {
            res.status(404).json({ message: 'Utilisateur introuvable' });
        }
    } catch (err) {
        res.status(500).json({ message: err.message });
    }
});

router.post('/', async (req, res) => {
    try {
        if (!username || !password || !email) {
            return res.status(400).json({ message: 'Nom d\'utilisateur, mot de passe et email sont requis.' });
        }

        const hashedPassword = await bcrypt.hash(req.body.password, 10);
        console.log(req.body)
        const user = await User.create({
            username: req.body.username,
            password: hashedPassword,
            email: req.body.email
        });

        res.status(201).json(user);
    } catch (err) {
        if (err.name === 'SequelizeUniqueConstraintError') {
            res.status(400).json({ message: 'Nom d\'utilisateur ou email déjà utilisé.' });
        } else {
            res.status(400).json({ message: err.message });
        }
    }
});

router.put('/:id', async (req, res) => {
    try {
        const user = await User.findByPk(req.params.id);
        if (user) {
            if (!username || !email) {
                return res.status(400).json({ message: 'Nom d\'utilisateur et email sont requis.' });
            }
            const hashedPassword = await bcrypt.hash(password, 10);
            
            await user.update({
                username: req.body.username,
                password: hashedPassword,
                email: req.body.email
            });

            res.json(user);
        } else {
            res.status(404).json({ message: 'Utilisateur trouvable' });
        }
    } catch (err) {
        res.status(400).json({ message: err.message });
    }
});

router.delete('/:id', async (req, res) => {
    try {
        const user = await User.findByPk(req.params.id);
        if (user) {
            await user.destroy();
            res.json({ message: 'Utilisateur supprimé' });
        } else {
            res.status(404).json({ message: 'Utilisateur introuvable' });
        }
    } catch (err) {
        res.status(500).json({ message: err.message });
    }
});

router.post('/:id/upload', authenticateToken, upload.single('cv'), async (req, res) => {
    try {
        const user = await User.findByPk(req.params.id);
        if (!user) return res.status(404).json({ message: 'L\'utilisateur n\'existe pas' });

        user.cv = req.file.path;
        await user.save();
        res.status(200).json({ message: 'CV uploaded successfully', cv: user.cv });
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
});

router.get('/:id/cv', authenticateToken, async (req, res) => {
    try {
        const user = await User.findByPk(req.params.id);
        if (!user || !user.cv) return res.status(404).json({ message: 'Aucun CV ressencé' });

        res.sendFile(path.resolve(user.cv));
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
});

module.exports = router;
