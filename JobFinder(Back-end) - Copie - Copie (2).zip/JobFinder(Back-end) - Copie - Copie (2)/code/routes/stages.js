const express = require('express');
const router = express.Router();
const { Stage } = require('../models');
const authenticateToken = require('../middleware/auth');

router.post('/', authenticateToken, async (req, res) => {
    try {
        const stage = await Stage.create(req.body);
        res.status(201).json(stage);
    } catch (err) {
        res.status(400).json({ message: err.message });
    }
});

router.get('/', authenticateToken, async (req, res) => {
    try {
        const stages = await Stage.findAll();
        res.json(stages);
    } catch (err) {
        res.status(500).json({ message: err.message });
    }
});

router.get('/:id', async (req, res) => {
    try {
        const stage = await Stage.findByPk(req.params.id);
        if (stage) {
            res.json(stage);
        } else {
            res.status(404).json({ message: 'Offre de stage non trouvee' });
        }
    } catch (err) {
        res.status(500).json({ message: err.message });
    }
});

router.put('/:id', async (req, res) => {
    try {
        const stage = await Stage.findByPk(req.params.id);
        if (stage) {
            await stage.update(req.body);
            res.json(stage);
        } else {
            res.status(404).json({ message: 'Offre de stage non trouvee' });
        }
    } catch (err) {
        res.status(400).json({ message: err.message });
    }
});

router.delete('/:id', async (req, res) => {
    try {
        const stage = await Stage.findByPk(req.params.id);
        if (stage) {
            await stage.destroy();
            res.json({ message: 'Offre de stage supprimee' });
        } else {
            res.status(404).json({ message: 'Offre de stage non trouvee' });
        }
    } catch (err) {
        res.status(500).json({ message: err.message });
    }
});

module.exports = router;
