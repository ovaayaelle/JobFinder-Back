const { Sequelize } = require('sequelize');

const sequelize = new Sequelize('JobFinder', 'root', '', {
    host: 'localhost',
    dialect: 'mysql'
});

module.exports = sequelize;
