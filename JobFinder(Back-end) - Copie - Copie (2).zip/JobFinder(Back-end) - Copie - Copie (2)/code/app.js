const express = require('express');
const sequelize = require('./config');
const bodyParser = require('body-parser');
const jobRoutes = require('./routes/jobs');
const stageRoutes = require('./routes/stages');
const userRoutes = require('./routes/users');
const authRoutes = require('./routes/auth');
const path = require('path');
const fs = require('fs');

const app = express();
const PORT = process.env.PORT || 3000;
const uploadDir = path.join(__dirname, 'uploads');
if (!fs.existsSync(uploadDir)) {
  fs.mkdirSync(uploadDir, { recursive: true });
}

app.use(express.json());
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));

app.use('/jobs', jobRoutes);
app.use('/stages', stageRoutes);
app.use('/users', userRoutes);
app.use('/auth', authRoutes);
app.use('/uploads', express.static('uploads'));

sequelize.sync().then(() => {
    console.log('Base de données synchronisée');
    app.listen(PORT, () => {
        console.log(`Serveur démarré sur le port ${PORT}`);
    });
}).catch(err => {
    console.error('Erreur de synchronisation de la base de données:', err);
});
